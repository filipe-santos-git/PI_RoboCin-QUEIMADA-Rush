#include "raylib.h"
#include "Bosses.h"
#include "Gameplay/player.h"
#include "General_Classes/Screen_Details.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


Boss dummy;


void CreateDummy()
{
    S_l = GetScreenWidth();
    S_a = GetScreenHeight();
    dummy.pos.x = S_l/16;
    dummy.pos.y = S_a/2;
    dummy.vel.x = 0;
    dummy.vel.y = 0;
    dummy.mana = 0;
    dummy.ataque = 0;
    dummy.height = 470;
    dummy.width = 300;
    dummy.pos.x -= dummy.width/2 - 110;
    dummy.pos.y -= dummy.height/2 + 30;
    dummy.color = RED;

}

void DummyUpdate(float dt)
{
    dummy.mana += 0.5 *dt;
    if(dummy.mana == 5)
    {
        dummy.mana = 0;
    }



}

void DummyDraw()
{
    DrawRectangle(dummy.pos.x, dummy.pos.y, dummy.width, dummy.height, dummy.color);
}


