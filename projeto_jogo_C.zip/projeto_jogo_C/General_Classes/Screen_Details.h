#ifndef DETAILS
#define DETAILS
#include "raylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int S_l;
int S_a;

#endif
