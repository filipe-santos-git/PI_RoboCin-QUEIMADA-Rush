#ifndef STATE
#define STATE
#include "raylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char state = 'M';

#endif






